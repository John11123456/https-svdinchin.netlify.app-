// 缓存版本号（后续更新内容时改这个数字，比如v2）
const CACHE_NAME = "与我同行-offline-v1";

// 🔥 核心：需要缓存的所有文件（已去重+统一路径格式，包含所有本地资源）
const OFFLINE_FILES = [
  // 主页面和配置文件
  "index.html",
  "icon-192x192.png",
  "icon-512x512.png",
  "splash.png",
  "manifest.json",
  "robots.txt",
  "_headers",
  // 所有子页面（已去重，统一不带 / ，与你的文件实际路径一致）
  "sub1-1-1.html", "sub1-1-2.html", "sub1-1-3.html", "sub1-1-4.html", "sub1-1-5.html",
  "sub1-1-6.html", "sub1-1-7.html", "sub1-1-8.html", "sub1-1-9.html",
  "sub1-2-1.html", "sub1-2-2.html", "sub1-2-3.html",
  "sub1-3-1.html", "sub1-3-2.html", "sub1-3-3.html",
  "sub1-4-1.html", "sub1-4-2.html", "sub1-4-3.html", "sub1-4-4.html", "sub1-4-5.html", "sub1-4-6.html",
  "sub1-5-1.html", "sub1-5-2.html", "sub1-5-3.html",
  "sub2-1-1.html", "sub2-2-1.html",
  "sub2-3-1.html", "sub2-3-2.html", "sub2-3-3.html", "sub2-3-4.html", "sub2-3-5.html", "sub2-3-6.html", "sub2-3-7.html", "sub2-3-8.html", "sub2-3-9.html",
  "sub2-4-1.html",
  "sub3-1-1.html", "sub3-1-2.html", "sub3-1-3.html", "sub3-1-4.html", "sub3-1-5.html", "sub3-1-6.html", "sub3-1-7.html",
  "sub3-2-1.html", "sub3-2-2.html", "sub3-2-3.html", "sub3-2-4.html", "sub3-2-5.html",
  "sub3-3-1.html", "sub3-3-2.html", "sub3-3-3.html", "sub3-3-4.html", "sub3-3-5.html",
  "sub3-4-1.html", "sub3-4-2.html", "sub3-4-3.html", "sub3-4-4.html", "sub3-4-5.html",
  "sub3-5-1.html", "sub3-5-2.html", "sub3-5-3.html", "sub3-5-4.html", "sub3-5-5.html",
  "sub3-6-1.html", "sub3-6-2.html",
  "sub4-1-1.html", "sub4-2-1.html", "sub4-3-1.html", "sub4-4-1.html", "sub4-5-1.html", "sub4-6-1.html", "sub4-7-1.html", "sub4-8-1.html",
  "sub5-1-1.html", "sub5-2-1.html", "sub5-3-1.html", "sub5-4-1.html", "sub5-5-1.html", "sub5-6-1.html", "sub5-7-1.html", "sub5-8-1.html", "sub5-9-1.html",
  "sub6-1-1.html", "sub6-1-2.html", "sub6-1-3.html", "sub6-1-4.html", "sub6-1-5.html", "sub6-1-6.html",
  "sub6-2-1.html", "sub6-2-2.html",
  "sub6-3-1.html", "sub6-3-2.html",
  "sub6-4-1.html", "sub6-4-2.html",
  "sub6-5-1.html", "sub6-5-2.html",
  "sub6-6-1.html", "sub6-6-2.html",
  "sub6-7-1.html", "sub6-7-2.html",
  "sub7-1-1.html", "sub7-2-1.html",
  "sub7-3-1.html", "sub7-3-2.html",
  "sub7-4-1.html", "sub7-4-2.html",
  "sub7-5-1.html", "sub7-5-2.html",
  "sub7-6-1.html", "sub7-6-2.html",
  "sub8-1-1.html",
  "sub8-2-1.html", "sub8-2-2.html", "sub8-2-3.html", "sub8-2-4.html", "sub8-2-5.html", "sub8-2-6.html", "sub8-2-7.html", "sub8-2-8.html", "sub8-2-9.html", "sub8-2-10.html",
  "sub8-2-11.html", "sub8-2-12.html", "sub8-2-13.html", "sub8-2-14.html", "sub8-2-15.html", "sub8-2-16.html", "sub8-2-17.html", "sub8-2-18.html", "sub8-2-19.html", "sub8-2-20.html",
  "sub8-2-21.html", "sub8-2-22.html", "sub8-2-23.html", "sub8-2-24.html", "sub8-2-25.html", "sub8-2-26.html", "sub8-2-27.html", "sub8-2-28.html", "sub8-2-29.html", "sub8-2-30.html",
  "sub8-2-31.html", "sub8-2-32.html", "sub8-2-33.html", "sub8-2-34.html", "sub8-2-35.html", "sub8-2-36.html", "sub8-2-37.html", "sub8-2-38.html", "sub8-2-39.html", "sub8-2-40.html",
  "sub8-2-41.html", "sub8-2-42.html", "sub8-2-43.html", "sub8-2-44.html", "sub8-2-45.html", "sub8-2-46.html",
  "sub8-3-1.html", "sub8-3-2.html", "sub8-3-3.html", "sub8-3-4.html", "sub8-3-5.html", "sub8-3-6.html", "sub8-3-7.html", "sub8-3-8.html", "sub8-3-9.html", "sub8-3-10.html",
  "sub8-3-11.html", "sub8-3-12.html", "sub8-3-13.html", "sub8-3-14.html", "sub8-3-15.html", "sub8-3-16.html", "sub8-3-17.html", "sub8-3-18.html", "sub8-3-19.html", "sub8-3-20.html",
  "sub8-3-21.html", "sub8-3-22.html", "sub8-3-23.html", "sub8-3-24.html", "sub8-3-25.html", "sub8-3-26.html", "sub8-3-27.html",
  "sub8-4-1.html", "sub8-4-2.html", "sub8-4-3.html", "sub8-4-4.html", "sub8-4-5.html", "sub8-4-6.html",
  "sub9-1-1.html", "sub9-2-1.html", "sub9-3-1.html", "sub9-4-1.html", "sub9-5-1.html", "sub9-6-1.html", "sub9-7-1.html", "sub9-8-1.html", "sub9-9-1.html", "sub9-10-1.html",
  "sub9-11-1.html", "sub9-12-1.html", "sub9-13-1.html", "sub9-14-1.html", "sub9-15-1.html", "sub9-16-1.html",
  "sub9-17-1.html", "sub9-17-2.html",
  "sub10-1-1.html", "sub10-1-2.html", "sub10-1-3.html",
  "sub10-2-1.html", "sub10-2-2.html", "sub10-2-3.html"
];

// 1. 安装Service Worker时，自动缓存所有本地资源（已修正变量名：用OFFLINE_FILES）
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log("开始自动缓存所有本地资源...");
        // 修正：调用正确的缓存清单数组OFFLINE_FILES
        return cache.addAll(OFFLINE_FILES);   // 这里必须是OFFLINE_FILES
      })
      .then(() => {
        // 安装完成后立即激活，无需等待页面刷新
        self.skipWaiting();
        console.log("所有资源缓存完成！断网后可浏览所有本地内容");
      })
  );
});

// 2. 激活Service Worker时，清理旧版本缓存（更新版本时自动删除旧文件）
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      // 删除非当前版本的缓存
      return Promise.all(
        cacheNames.filter(name => name !== CACHE_NAME)
          .map(name => caches.delete(name))
      );
    }).then(() => {
      // 控制所有打开的页面，确保缓存生效
      return self.clients.claim();
    })
  );
});

// 3. 拦截请求，优先从缓存返回（断网时生效，外部链接单独处理）
self.addEventListener('fetch', (event) => {
  // 外部链接（http/https开头且不是自己的域名）直接放行，不缓存
  if (event.request.url.startsWith('http') && !event.request.url.includes(self.location.hostname)) {
    event.respondWith(fetch(event.request).catch(() => {
      // 外部链接断网时返回提示
      return new Response('<div style="text-align:center;padding:2rem;">请联网后访问外部链接</div>', {
        headers: { 'Content-Type': 'text/html; charset=utf-8' }
      });
    }));
    return;
  }

  // 本地资源：优先从缓存读取，缓存没有再从网络获取并更新缓存
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        if (response) {
          // 缓存命中，直接返回
          return response;
        }
        // 缓存未命中（理论上不会发生，因已预缓存所有本地资源），从网络获取并更新缓存
        return fetch(event.request)
          .then((networkResponse) => {
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, networkResponse.clone());
            });
            return networkResponse;
          })
          .catch(() => {
            // 断网且无缓存时的提示
            return new Response('<div style="text-align:center;padding:2rem;">资源未缓存，请联网后重试</div>', {
              headers: { 'Content-Type': 'text/html; charset=utf-8' }
            });
          });
      })
  );
});